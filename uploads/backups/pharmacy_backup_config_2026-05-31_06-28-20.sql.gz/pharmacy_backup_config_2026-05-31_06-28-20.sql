-- Pharmacy Management System Database Backup
-- Type: CONFIG
-- Generated: 2026-05-31 06:28:20
-- Database: pharmacy_db
-- Server: localhost

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';

-- ─────────────────────────────────────────────
-- Table: `company_settings`
-- ─────────────────────────────────────────────
DROP TABLE IF EXISTS `company_settings`;
CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gst_no` varchar(50) DEFAULT NULL,
  `tin_no` varchar(50) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT 'Thank you! Visit Again',
  `currency_symbol` varchar(10) DEFAULT '₹',
  `invoice_prefix` varchar(20) DEFAULT 'INV',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `pharmacy_tagline` varchar(255) DEFAULT 'Your Health, Our Priority',
  `pharmacy_type` enum('pharmacy','medical_store','dispensary','chemist') DEFAULT 'pharmacy',
  `logo_path` varchar(255) DEFAULT NULL,
  `favicon_path` varchar(255) DEFAULT NULL,
  `primary_color` varchar(7) DEFAULT '#0d6efd',
  `sidebar_color` varchar(7) DEFAULT '#212529',
  `accent_color` varchar(7) DEFAULT '#198754',
  `show_logo_on_invoice` tinyint(1) DEFAULT 1,
  `show_logo_on_sidebar` tinyint(1) DEFAULT 1,
  `show_tagline_on_invoice` tinyint(1) DEFAULT 1,
  `receipt_paper_size` enum('A4','A5','80mm','58mm') DEFAULT 'A4',
  `low_stock_threshold` int(11) DEFAULT 10,
  `near_expiry_days` int(11) DEFAULT 30,
  `default_tax_rate` decimal(5,2) DEFAULT 0.00,
  `invoice_terms` text DEFAULT NULL,
  `invoice_footer_text` varchar(255) DEFAULT NULL,
  `show_payment_on_invoice` tinyint(1) DEFAULT 1,
  `show_batch_on_invoice` tinyint(1) DEFAULT 1,
  `system_timezone` varchar(50) DEFAULT 'Asia/Karachi',
  `date_format` varchar(20) DEFAULT 'd M Y',
  `time_format` varchar(10) DEFAULT 'h:i A',
  `session_timeout` int(11) DEFAULT 60,
  `default_language` varchar(10) DEFAULT 'en',
  `license_number` varchar(100) DEFAULT NULL,
  `owner_name` varchar(150) DEFAULT NULL,
  `password_change_days` int(11) DEFAULT 90,
  `login_attempts_limit` int(11) DEFAULT 5,
  `lockout_duration` int(11) DEFAULT 15,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `ip_whitelist` text DEFAULT NULL,
  `invoice_footer_note` varchar(255) DEFAULT NULL,
  `show_discount_on_invoice` tinyint(1) DEFAULT 1,
  `show_tax_on_invoice` tinyint(1) DEFAULT 1,
  `drug_license_no` varchar(100) DEFAULT NULL,
  `ntn_number` varchar(50) DEFAULT NULL,
  `strn_number` varchar(50) DEFAULT NULL,
  `max_login_attempts` int(11) DEFAULT 5,
  `password_expire_days` int(11) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `pharmacy_name` varchar(150) DEFAULT NULL COMMENT 'Alias — your table uses company_name as primary name',
  `dark_mode` tinyint(1) DEFAULT 0,
  `theme_preset` varchar(30) DEFAULT 'default',
  `body_font_family` varchar(60) DEFAULT 'Segoe UI',
  `body_font_size` int(11) DEFAULT 14,
  `heading_color` varchar(7) DEFAULT '#1a1d23',
  `body_text_color` varchar(7) DEFAULT '#444444',
  `card_bg_color` varchar(7) DEFAULT '#ffffff',
  `body_bg_color` varchar(7) DEFAULT '#f0f2f5',
  `dark_bg_color` varchar(7) DEFAULT '#0f1117',
  `dark_sidebar_color` varchar(7) DEFAULT '#161b22',
  `dark_card_color` varchar(7) DEFAULT '#1c2128',
  `dark_text_color` varchar(7) DEFAULT '#e6edf3',
  `table_striped` tinyint(1) DEFAULT 1,
  `sidebar_compact` tinyint(1) DEFAULT 0,
  `navbar_bg_color` varchar(7) DEFAULT '#ffffff',
  `navbar_border_color` varchar(7) DEFAULT '#e9ecef',
  `sidebar_text_color` varchar(7) DEFAULT '#a0aec0',
  `link_color` varchar(7) DEFAULT '#0d6efd',
  `border_color` varchar(7) DEFAULT '#dee2e6',
  `table_header_color` varchar(7) DEFAULT '#f8f9fa',
  `table_stripe_color` varchar(7) DEFAULT '#f9f9ff',
  `modal_header_color` varchar(7) DEFAULT '#0d6efd',
  `input_focus_color` varchar(7) DEFAULT '#667eea',
  `badge_instock_bg` varchar(7) DEFAULT '#d1fae5',
  `badge_instock_text` varchar(7) DEFAULT '#065f46',
  `badge_oos_bg` varchar(7) DEFAULT '#fee2e2',
  `badge_oos_text` varchar(7) DEFAULT '#991b1b',
  `badge_expiry_bg` varchar(7) DEFAULT '#fff3cd',
  `badge_expiry_text` varchar(7) DEFAULT '#856404',
  `badge_lowstock_bg` varchar(7) DEFAULT '#fff7e6',
  `badge_lowstock_text` varchar(7) DEFAULT '#c2410c',
  `badge_expired_bg` varchar(7) DEFAULT '#fce7f3',
  `badge_expired_text` varchar(7) DEFAULT '#9d174d',
  `card_border_radius` int(11) DEFAULT 12,
  `btn_border_radius` int(11) DEFAULT 8,
  `shadow_intensity` int(11) DEFAULT 12,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `company_settings`
INSERT INTO `company_settings` (`id`, `company_name`, `company_logo`, `phone`, `email`, `address`, `gst_no`, `tin_no`, `footer_text`, `currency_symbol`, `invoice_prefix`, `created_at`, `pharmacy_tagline`, `pharmacy_type`, `logo_path`, `favicon_path`, `primary_color`, `sidebar_color`, `accent_color`, `show_logo_on_invoice`, `show_logo_on_sidebar`, `show_tagline_on_invoice`, `receipt_paper_size`, `low_stock_threshold`, `near_expiry_days`, `default_tax_rate`, `invoice_terms`, `invoice_footer_text`, `show_payment_on_invoice`, `show_batch_on_invoice`, `system_timezone`, `date_format`, `time_format`, `session_timeout`, `default_language`, `license_number`, `owner_name`, `password_change_days`, `login_attempts_limit`, `lockout_duration`, `two_factor_enabled`, `ip_whitelist`, `invoice_footer_note`, `show_discount_on_invoice`, `show_tax_on_invoice`, `drug_license_no`, `ntn_number`, `strn_number`, `max_login_attempts`, `password_expire_days`, `updated_by`, `pharmacy_name`, `dark_mode`, `theme_preset`, `body_font_family`, `body_font_size`, `heading_color`, `body_text_color`, `card_bg_color`, `body_bg_color`, `dark_bg_color`, `dark_sidebar_color`, `dark_card_color`, `dark_text_color`, `table_striped`, `sidebar_compact`, `navbar_bg_color`, `navbar_border_color`, `sidebar_text_color`, `link_color`, `border_color`, `table_header_color`, `table_stripe_color`, `modal_header_color`, `input_focus_color`, `badge_instock_bg`, `badge_instock_text`, `badge_oos_bg`, `badge_oos_text`, `badge_expiry_bg`, `badge_expiry_text`, `badge_lowstock_bg`, `badge_lowstock_text`, `badge_expired_bg`, `badge_expired_text`, `card_border_radius`, `btn_border_radius`, `shadow_intensity`) VALUES ('1', 'Arslan\'s', NULL, '03003567305', 'dr.arslanyasin@gmail.com', 'Adda Kacha Pakka', '', '', 'Thank you for shopping with us!', 'Rs', 'INV', '2026-05-05 18:40:32', 'Health is Good', 'pharmacy', 'uploads/settings/logo_1780185993.png', 'uploads/settings/favicon_1780185993.png', '#059669', '#d69595', '#10b981', '1', '1', '1', '80mm', '10', '30', '10.00', 'Goods Sold Cannt be Returend', 'Thank you for shopping with us!', '1', '1', 'Asia/Karachi', 'd M Y', 'h:i A', '60', 'ur', '', '', '90', '5', '15', '0', '', NULL, '1', '1', NULL, NULL, NULL, '5', '0', NULL, 'Arslan\'s', '0', 'default', 'Segoe UI', '14', '#1a1d23', '#444444', '#ffffff', '#f0f2f5', '#0f1117', '#161b22', '#1c2128', '#e6edf3', '1', '1', '#d69595', '#294561', '#f2e8ef', '#1c100d', '#3d546c', '#a1afa9', '#cbcbe7', '#92a8c9', '#acc4dc', '#f0f5f2', '#061914', '#fee2e2', '#991b1b', '#fff3cd', '#856404', '#fff7e6', '#c2410c', '#fce7f3', '#9d174d', '28', '20', '28');

-- ─────────────────────────────────────────────
-- Table: `users`
-- ─────────────────────────────────────────────
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','pharmacist','cashier') DEFAULT 'pharmacist',
  `profile_image` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `permissions_set` tinyint(1) DEFAULT 0 COMMENT '1 = admin has customised permissions for this user',
  `remember_expires` datetime DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `default_page` varchar(50) DEFAULT 'dashboard',
  `session_timeout_override` int(11) DEFAULT NULL COMMENT 'Overrides global session_timeout for this user (minutes)',
  `remember_token_expires` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `login_count` int(11) DEFAULT 0,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `force_password_change` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `security_question` varchar(100) DEFAULT NULL,
  `security_answer` varchar(255) DEFAULT NULL,
  `is_first_login` tinyint(1) NOT NULL DEFAULT 1,
  `session_token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_remember_token` (`remember_token`(32)),
  KEY `idx_username` (`username`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `users`
INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `phone`, `role`, `profile_image`, `last_login`, `remember_token`, `reset_token`, `reset_expires`, `status`, `created_at`, `updated_at`, `permissions_set`, `remember_expires`, `profile_photo`, `default_page`, `session_timeout_override`, `remember_token_expires`, `created_by`, `notes`, `login_count`, `last_login_ip`, `password_changed_at`, `force_password_change`, `is_active`, `security_question`, `security_answer`, `is_first_login`, `session_token`) VALUES ('1', 'admin', '$2y$12$s2jjIoigUb/ub.nYyfIb8.pWkBHvyHzyERSpXAKCB4oX8LGBpSQeu', 'Arslan YASIN', 'admin@pharmacy.com', '9876543210', 'admin', 'profile_1_1780188232.png', '2026-05-31 05:39:11', NULL, NULL, NULL, '1', '2026-05-05 18:40:31', '2026-05-29 12:03:55', '1', NULL, 'user_1_1780038214.png', 'dashboard', NULL, NULL, NULL, '', '52', NULL, NULL, '0', '1', 'phone', '$2y$12$mVLcVy7M12N0xr8otzoMAujowmeMDfxfZNJvjM29AEI1nl/ZmNRsK', '0', NULL);
INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `phone`, `role`, `profile_image`, `last_login`, `remember_token`, `reset_token`, `reset_expires`, `status`, `created_at`, `updated_at`, `permissions_set`, `remember_expires`, `profile_photo`, `default_page`, `session_timeout_override`, `remember_token_expires`, `created_by`, `notes`, `login_count`, `last_login_ip`, `password_changed_at`, `force_password_change`, `is_active`, `security_question`, `security_answer`, `is_first_login`, `session_token`) VALUES ('7', 'BHAI', '$2y$12$d/D75FUnw67fZH.dAjKd6uu/devWM5BQJzM7aWjclgCPVBTMM./W2', 'KHAN', 'AJD@G.COM', '4334', 'cashier', NULL, '2026-05-29 13:01:32', NULL, NULL, NULL, '1', '2026-05-29 12:55:42', '2026-05-31 05:53:38', '0', NULL, 'user_6a19467e722fe.PNG', 'dashboard', NULL, NULL, NULL, '', '1', NULL, NULL, '0', '1', 'phone', '$2y$10$DcA.fqY/MY.tgPvx/iRq6.RXZ48khTQS7mqmhBJ8XvnlIlxx3OzvW', '0', NULL);
INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `phone`, `role`, `profile_image`, `last_login`, `remember_token`, `reset_token`, `reset_expires`, `status`, `created_at`, `updated_at`, `permissions_set`, `remember_expires`, `profile_photo`, `default_page`, `session_timeout_override`, `remember_token_expires`, `created_by`, `notes`, `login_count`, `last_login_ip`, `password_changed_at`, `force_password_change`, `is_active`, `security_question`, `security_answer`, `is_first_login`, `session_token`) VALUES ('8', 'aaaaaaa', '$2y$12$7J5W9vkw7vK7A4BFYL/G3OJslZF9YIVafBZD/wybxTd5Ljo9YidEm', 'aaaaaaaaa', 'adh@thg.com', '', 'cashier', NULL, NULL, NULL, NULL, NULL, '1', '2026-05-31 05:54:32', NULL, '0', NULL, 'user_6a1b86c82ed8a.PNG', 'dashboard', NULL, NULL, NULL, NULL, '0', NULL, NULL, '0', '1', 'phone', '$2y$10$y02BWxtJd2tdGKZ7lTqj3.1oGbuk.kZk6IBA8pCCko1VQej0ApE22', '1', NULL);

-- ─────────────────────────────────────────────
-- Table: `user_permissions`
-- ─────────────────────────────────────────────
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module` varchar(50) NOT NULL,
  `can_view` tinyint(1) DEFAULT 0,
  `can_add` tinyint(1) DEFAULT 0,
  `can_edit` tinyint(1) DEFAULT 0,
  `can_delete` tinyint(1) DEFAULT 0,
  `can_print` tinyint(1) DEFAULT 0,
  `can_export` tinyint(1) DEFAULT 0,
  `can_import` tinyint(1) DEFAULT 0,
  `can_void` tinyint(1) DEFAULT 0,
  `can_reset` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_module` (`user_id`,`module`),
  KEY `idx_user_perm_user` (`user_id`),
  KEY `idx_user_perm_module` (`module`),
  CONSTRAINT `fk_up_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Per-user module-level access control';

-- Data for `user_permissions`
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('42', '1', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('43', '1', 'products', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('44', '1', 'sales', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('45', '1', 'purchases', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('46', '1', 'returns', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('47', '1', 'credits', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('48', '1', 'suppliers', '1', '1', '1', '1', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('49', '1', 'cashbook', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('50', '1', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('51', '1', 'reports', '1', '0', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('52', '1', 'users', '1', '1', '1', '1', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('53', '1', 'settings', '1', '0', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('54', '1', 'backup', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('107', '7', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('108', '7', 'products', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('109', '7', 'sales', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('110', '7', 'purchases', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('111', '7', 'returns', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('112', '7', 'credits', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('113', '7', 'suppliers', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('114', '7', 'cashbook', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('115', '7', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('116', '7', 'reports', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('117', '7', 'users', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('118', '7', 'settings', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('119', '7', 'backup', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('120', '8', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('121', '8', 'products', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('122', '8', 'sales', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('123', '8', 'purchases', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('124', '8', 'returns', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('125', '8', 'credits', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('126', '8', 'suppliers', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('127', '8', 'cashbook', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('128', '8', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('129', '8', 'reports', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('130', '8', 'users', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('131', '8', 'settings', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('132', '8', 'backup', '0', '0', '0', '0', '0', '0', '0', '0', '0');

-- ─────────────────────────────────────────────
-- Table: `permission_presets`
-- ─────────────────────────────────────────────
DROP TABLE IF EXISTS `permission_presets`;
CREATE TABLE `permission_presets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preset_name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `permissions_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`permissions_json`)),
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for `permission_presets`
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('1', 'Admin Full Access', 'admin', '{\"dashboard\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 1}, \"products\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"purchases\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"suppliers\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 1, \"void\": 0}}', '1', '2026-05-20 08:40:33');
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('2', 'Pharmacist Standard', 'pharmacist', '{\"dashboard\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"products\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"purchases\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"suppliers\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}}', '1', '2026-05-20 08:40:33');
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('3', 'Cashier Basic', 'cashier', '{\"dashboard\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"products\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"purchases\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"suppliers\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}}', '1', '2026-05-20 08:40:33');

-- ─────────────────────────────────────────────
-- Table: `system_resets`
-- ─────────────────────────────────────────────
DROP TABLE IF EXISTS `system_resets`;
CREATE TABLE `system_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_type` enum('full','financial','transaction') NOT NULL,
  `reset_by` int(11) NOT NULL,
  `reset_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `backup_filename_before` varchar(255) DEFAULT NULL,
  `rows_deleted_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Counts of rows deleted per table' CHECK (json_valid(`rows_deleted_json`)),
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reset_at` (`reset_at`),
  KEY `idx_reset_by` (`reset_by`),
  KEY `idx_reset_type` (`reset_type`),
  KEY `idx_system_resets_at` (`reset_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;
-- End of backup — 5 tables, 46 rows
