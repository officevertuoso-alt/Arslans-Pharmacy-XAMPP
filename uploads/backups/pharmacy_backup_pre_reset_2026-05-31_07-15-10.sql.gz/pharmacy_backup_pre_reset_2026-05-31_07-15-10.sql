-- Pharmacy Management System — Full Backup
-- Source: factory_reset
-- Generated: 2026-05-31 07:15:10

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_activity_user` (`user_id`,`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_type` enum('full','data','selective','config') NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `md5_checksum` varchar(32) DEFAULT NULL,
  `tables_included` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `reorder_level` int(11) NOT NULL DEFAULT 0,
  `pack_quantity` int(11) NOT NULL COMMENT 'Number of packs purchased',
  `pieces_per_pack` int(11) NOT NULL COMMENT 'Pieces in each pack (e.g., 10 tablets)',
  `total_pieces` int(11) NOT NULL COMMENT 'pack_quantity * pieces_per_pack',
  `remaining_quantity` int(11) NOT NULL COMMENT 'Remaining pieces',
  `manufacture_date` date DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `purchase_date` date NOT NULL,
  `is_expired` tinyint(1) DEFAULT 0,
  `is_blocked` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `units_per_pack` int(11) DEFAULT 1,
  `pack_type` varchar(50) DEFAULT NULL,
  `quantity_of_packs` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `expiry_date` (`expiry_date`),
  KEY `idx_batches_expiry` (`expiry_date`),
  KEY `idx_batches_product` (`product_id`),
  KEY `idx_batches_product_expiry` (`product_id`,`expiry_date`,`remaining_quantity`),
  KEY `idx_batches_remaining` (`remaining_quantity`,`is_expired`),
  KEY `idx_batch_expiry` (`expiry_date`,`remaining_quantity`),
  KEY `idx_batch_product` (`product_id`,`expiry_date`),
  KEY `idx_batches_product_active` (`product_id`,`remaining_quantity`,`is_expired`),
  KEY `idx_fifo` (`product_id`,`expiry_date`,`id`),
  KEY `idx_expired` (`is_expired`),
  CONSTRAINT `batches_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `batches_ibfk_2` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batches_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `bulk_import_logs`;
CREATE TABLE `bulk_import_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_type` enum('medicine','non_medicine') NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_filename` varchar(255) DEFAULT NULL,
  `total_rows` int(11) DEFAULT 0,
  `success_rows` int(11) DEFAULT 0,
  `failed_rows` int(11) DEFAULT 0,
  `warning_rows` int(11) DEFAULT 0,
  `errors_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`errors_json`)),
  `imported_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_import_type` (`import_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_imported_by` (`imported_by`),
  KEY `idx_bulk_import_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for `bulk_import_logs`
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('1', 'medicine', 'pharmacy_medicine_import_template.csv', NULL, '1', '1', '0', '0', '[]', '1', '2026-05-20 17:17:47');
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('2', 'non_medicine', 'pharmacy_nonmedicine_import_template.csv', NULL, '1', '1', '0', '0', '[]', '1', '2026-05-20 17:18:55');
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('3', 'medicine', 'medicine_import_template.csv', NULL, '1', '1', '0', '0', '[]', '1', '2026-05-20 17:41:33');
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('4', 'non_medicine', 'non_medicine_import_template.csv', NULL, '1', '1', '0', '0', '[]', '1', '2026-05-20 17:43:34');
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('5', 'medicine', 'medicine_import_template.csv', NULL, '1', '0', '0', '0', '[]', '1', '2026-05-20 17:47:00');
INSERT INTO `bulk_import_logs` (`id`, `import_type`, `filename`, `original_filename`, `total_rows`, `success_rows`, `failed_rows`, `warning_rows`, `errors_json`, `imported_by`, `created_at`) VALUES ('6', 'medicine', 'medicine_import_template (1).csv', NULL, '1', '0', '0', '0', '[]', '1', '2026-05-25 03:26:56');

DROP TABLE IF EXISTS `cashbook`;
CREATE TABLE `cashbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `entry_type` enum('sale','purchase_payment','credit_received','expense','sale_return','purchase_return','opening','closing') NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `reference_type` varchar(30) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `debit` decimal(12,2) DEFAULT 0.00,
  `credit` decimal(12,2) DEFAULT 0.00,
  `balance` decimal(12,2) DEFAULT 0.00,
  `payment_method` enum('cash','card','online','cheque','bank') DEFAULT 'cash',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `voided` tinyint(1) NOT NULL DEFAULT 0,
  `voided_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cashbook_date` (`entry_date`),
  KEY `idx_cashbook_type` (`entry_type`),
  KEY `idx_cashbook_created_by` (`created_by`),
  KEY `idx_cashbook_date_type` (`entry_date`,`entry_type`),
  KEY `idx_cashbook_reference` (`reference_id`,`reference_type`),
  KEY `idx_cashbook_entry_type` (`entry_type`),
  KEY `idx_cashbook_entry_date` (`entry_date`),
  KEY `idx_voided` (`voided`),
  CONSTRAINT `fk_cashbook_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Daily cash ledger — debit/credit entries';

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `company_settings`;
CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gst_no` varchar(50) DEFAULT NULL,
  `tin_no` varchar(50) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT 'Thank you! Visit Again',
  `currency_symbol` varchar(10) DEFAULT '₹',
  `invoice_prefix` varchar(20) DEFAULT 'INV',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `pharmacy_tagline` varchar(255) DEFAULT 'Your Health, Our Priority',
  `pharmacy_type` enum('pharmacy','medical_store','dispensary','chemist') DEFAULT 'pharmacy',
  `logo_path` varchar(255) DEFAULT NULL,
  `favicon_path` varchar(255) DEFAULT NULL,
  `primary_color` varchar(7) DEFAULT '#0d6efd',
  `sidebar_color` varchar(7) DEFAULT '#212529',
  `accent_color` varchar(7) DEFAULT '#198754',
  `show_logo_on_invoice` tinyint(1) DEFAULT 1,
  `show_logo_on_sidebar` tinyint(1) DEFAULT 1,
  `show_tagline_on_invoice` tinyint(1) DEFAULT 1,
  `receipt_paper_size` enum('A4','A5','80mm','58mm') DEFAULT 'A4',
  `low_stock_threshold` int(11) DEFAULT 10,
  `near_expiry_days` int(11) DEFAULT 30,
  `default_tax_rate` decimal(5,2) DEFAULT 0.00,
  `invoice_terms` text DEFAULT NULL,
  `invoice_footer_text` varchar(255) DEFAULT NULL,
  `show_payment_on_invoice` tinyint(1) DEFAULT 1,
  `show_batch_on_invoice` tinyint(1) DEFAULT 1,
  `system_timezone` varchar(50) DEFAULT 'Asia/Karachi',
  `date_format` varchar(20) DEFAULT 'd M Y',
  `time_format` varchar(10) DEFAULT 'h:i A',
  `session_timeout` int(11) DEFAULT 60,
  `default_language` varchar(10) DEFAULT 'en',
  `license_number` varchar(100) DEFAULT NULL,
  `owner_name` varchar(150) DEFAULT NULL,
  `password_change_days` int(11) DEFAULT 90,
  `login_attempts_limit` int(11) DEFAULT 5,
  `lockout_duration` int(11) DEFAULT 15,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `ip_whitelist` text DEFAULT NULL,
  `invoice_footer_note` varchar(255) DEFAULT NULL,
  `show_discount_on_invoice` tinyint(1) DEFAULT 1,
  `show_tax_on_invoice` tinyint(1) DEFAULT 1,
  `drug_license_no` varchar(100) DEFAULT NULL,
  `ntn_number` varchar(50) DEFAULT NULL,
  `strn_number` varchar(50) DEFAULT NULL,
  `max_login_attempts` int(11) DEFAULT 5,
  `password_expire_days` int(11) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `pharmacy_name` varchar(150) DEFAULT NULL COMMENT 'Alias — your table uses company_name as primary name',
  `dark_mode` tinyint(1) DEFAULT 0,
  `theme_preset` varchar(30) DEFAULT 'default',
  `body_font_family` varchar(60) DEFAULT 'Segoe UI',
  `body_font_size` int(11) DEFAULT 14,
  `heading_color` varchar(7) DEFAULT '#1a1d23',
  `body_text_color` varchar(7) DEFAULT '#444444',
  `card_bg_color` varchar(7) DEFAULT '#ffffff',
  `body_bg_color` varchar(7) DEFAULT '#f0f2f5',
  `dark_bg_color` varchar(7) DEFAULT '#0f1117',
  `dark_sidebar_color` varchar(7) DEFAULT '#161b22',
  `dark_card_color` varchar(7) DEFAULT '#1c2128',
  `dark_text_color` varchar(7) DEFAULT '#e6edf3',
  `table_striped` tinyint(1) DEFAULT 1,
  `sidebar_compact` tinyint(1) DEFAULT 0,
  `navbar_bg_color` varchar(7) DEFAULT '#ffffff',
  `navbar_border_color` varchar(7) DEFAULT '#e9ecef',
  `sidebar_text_color` varchar(7) DEFAULT '#a0aec0',
  `link_color` varchar(7) DEFAULT '#0d6efd',
  `border_color` varchar(7) DEFAULT '#dee2e6',
  `table_header_color` varchar(7) DEFAULT '#f8f9fa',
  `table_stripe_color` varchar(7) DEFAULT '#f9f9ff',
  `modal_header_color` varchar(7) DEFAULT '#0d6efd',
  `input_focus_color` varchar(7) DEFAULT '#667eea',
  `badge_instock_bg` varchar(7) DEFAULT '#d1fae5',
  `badge_instock_text` varchar(7) DEFAULT '#065f46',
  `badge_oos_bg` varchar(7) DEFAULT '#fee2e2',
  `badge_oos_text` varchar(7) DEFAULT '#991b1b',
  `badge_expiry_bg` varchar(7) DEFAULT '#fff3cd',
  `badge_expiry_text` varchar(7) DEFAULT '#856404',
  `badge_lowstock_bg` varchar(7) DEFAULT '#fff7e6',
  `badge_lowstock_text` varchar(7) DEFAULT '#c2410c',
  `badge_expired_bg` varchar(7) DEFAULT '#fce7f3',
  `badge_expired_text` varchar(7) DEFAULT '#9d174d',
  `card_border_radius` int(11) DEFAULT 12,
  `btn_border_radius` int(11) DEFAULT 8,
  `shadow_intensity` int(11) DEFAULT 12,
  `auto_backup_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `auto_backup_keep` int(11) NOT NULL DEFAULT 10,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `company_settings`
INSERT INTO `company_settings` (`id`, `company_name`, `company_logo`, `phone`, `email`, `address`, `gst_no`, `tin_no`, `footer_text`, `currency_symbol`, `invoice_prefix`, `created_at`, `pharmacy_tagline`, `pharmacy_type`, `logo_path`, `favicon_path`, `primary_color`, `sidebar_color`, `accent_color`, `show_logo_on_invoice`, `show_logo_on_sidebar`, `show_tagline_on_invoice`, `receipt_paper_size`, `low_stock_threshold`, `near_expiry_days`, `default_tax_rate`, `invoice_terms`, `invoice_footer_text`, `show_payment_on_invoice`, `show_batch_on_invoice`, `system_timezone`, `date_format`, `time_format`, `session_timeout`, `default_language`, `license_number`, `owner_name`, `password_change_days`, `login_attempts_limit`, `lockout_duration`, `two_factor_enabled`, `ip_whitelist`, `invoice_footer_note`, `show_discount_on_invoice`, `show_tax_on_invoice`, `drug_license_no`, `ntn_number`, `strn_number`, `max_login_attempts`, `password_expire_days`, `updated_by`, `pharmacy_name`, `dark_mode`, `theme_preset`, `body_font_family`, `body_font_size`, `heading_color`, `body_text_color`, `card_bg_color`, `body_bg_color`, `dark_bg_color`, `dark_sidebar_color`, `dark_card_color`, `dark_text_color`, `table_striped`, `sidebar_compact`, `navbar_bg_color`, `navbar_border_color`, `sidebar_text_color`, `link_color`, `border_color`, `table_header_color`, `table_stripe_color`, `modal_header_color`, `input_focus_color`, `badge_instock_bg`, `badge_instock_text`, `badge_oos_bg`, `badge_oos_text`, `badge_expiry_bg`, `badge_expiry_text`, `badge_lowstock_bg`, `badge_lowstock_text`, `badge_expired_bg`, `badge_expired_text`, `card_border_radius`, `btn_border_radius`, `shadow_intensity`, `auto_backup_enabled`, `auto_backup_keep`) VALUES ('1', 'Arslan\'s', NULL, '03003567305', 'dr.arslanyasin@gmail.com', 'Adda Kacha Pakka', '', '', 'Thank you for shopping with us!', 'Rs', 'INV', '2026-05-05 18:40:32', 'Health is Good', 'pharmacy', 'uploads/settings/logo_1780185993.png', 'uploads/settings/favicon_1780185993.png', '#dc2626', '#2c0000', '#ef4444', '1', '1', '1', '80mm', '10', '30', '10.00', 'Goods Sold Cannt be Returend', 'Thank you for shopping with us!', '1', '1', 'Asia/Karachi', 'd M Y', 'h:i A', '60', 'ur', '', '', '90', '5', '15', '0', '', NULL, '1', '1', NULL, NULL, NULL, '5', '0', NULL, 'Arslan\'s', '1', 'red', 'Segoe UI', '14', '#450a0a', '#7f1d1d', '#ffffff', '#fff5f5', '#0f1117', '#161b22', '#1c2128', '#e6edf3', '1', '1', '#ffffff', '#010304', '#171717', '#1c100d', '#3d546c', '#fff0f0', '#cbcbe7', '#92a8c9', '#acc4dc', '#f0f5f2', '#061914', '#fee2e2', '#991b1b', '#fff3cd', '#856404', '#fff7e6', '#c2410c', '#fce7f3', '#9d174d', '28', '20', '28', '1', '10');

DROP TABLE IF EXISTS `credit_payments`;
CREATE TABLE `credit_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','card','online') NOT NULL,
  `note` text DEFAULT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `credit_id` (`credit_id`),
  CONSTRAINT `credit_payments_ibfk_1` FOREIGN KEY (`credit_id`) REFERENCES `customer_credits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `customer_credits`;
CREATE TABLE `customer_credits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL COMMENT 'Linked sale if from POS',
  `customer_name` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','paid','cancelled','overdue') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `idx_sale_id` (`sale_id`),
  KEY `idx_status_due` (`status`,`due_date`),
  KEY `idx_credits_status_due` (`status`,`due_date`),
  KEY `idx_status` (`status`),
  KEY `idx_phone` (`customer_phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `custom_strengths`;
CREATE TABLE `custom_strengths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `strength` varchar(100) NOT NULL,
  `unit` varchar(50) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_strength` (`strength`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for `custom_strengths`
INSERT INTO `custom_strengths` (`id`, `strength`, `unit`, `created_at`) VALUES ('1', '450MG', '', '2026-05-24 21:09:23');
INSERT INTO `custom_strengths` (`id`, `strength`, `unit`, `created_at`) VALUES ('2', '100mg', '', '2026-05-25 04:14:34');

DROP TABLE IF EXISTS `dosage_forms`;
CREATE TABLE `dosage_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(50) NOT NULL,
  `usage_count` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_name` (`form_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `dosage_forms`
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('1', 'Tablet', '65', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('2', 'Capsule', '4', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('3', 'Syrup', '14', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('4', 'Injection', '2', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('5', 'Ointment', '1', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('6', 'Drops', '2', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('7', 'Diaper', '7', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('8', 'Shampoo', '3', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('9', 'Soap', '1', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('10', 'Cream', '1', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('11', 'Lotion', '1', '2026-05-05 18:40:31');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('12', 't', '4', '2026-05-11 19:31:22');
INSERT INTO `dosage_forms` (`id`, `form_name`, `usage_count`, `created_at`) VALUES ('13', 'Tablets', '1', '2026-05-23 23:40:16');

DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_date` date NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','bank','online','cheque') DEFAULT 'cash',
  `receipt_note` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_expenses_date` (`expense_date`),
  KEY `idx_expenses_category` (`category`),
  KEY `fk_expenses_user` (`created_by`),
  CONSTRAINT `fk_expenses_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Expense tracking — cash / bank / online payments';

DROP TABLE IF EXISTS `invoice_sequences`;
CREATE TABLE `invoice_sequences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefix` varchar(10) NOT NULL,
  `year` smallint(6) NOT NULL,
  `month` tinyint(4) NOT NULL,
  `last_number` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sequence` (`prefix`,`year`,`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Atomic invoice/sequence number generator — race condition safe';

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `success` tinyint(1) DEFAULT 0,
  `user_agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username_ip` (`username`,`ip_address`),
  KEY `idx_attempted_at` (`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `permission_presets`;
CREATE TABLE `permission_presets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preset_name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `permissions_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`permissions_json`)),
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for `permission_presets`
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('1', 'Admin Full Access', 'admin', '{\"dashboard\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 1}, \"products\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"purchases\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"suppliers\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 1, \"print\": 0, \"export\": 1, \"import\": 1, \"void\": 0}}', '1', '2026-05-20 08:40:33');
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('2', 'Pharmacist Standard', 'pharmacist', '{\"dashboard\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"products\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 1, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 1}, \"purchases\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"suppliers\": {\"view\": 1, \"add\": 1, \"edit\": 1, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 1, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}}', '1', '2026-05-20 08:40:33');
INSERT INTO `permission_presets` (`id`, `preset_name`, `role`, `permissions_json`, `is_default`, `created_at`) VALUES ('3', 'Cashier Basic', 'cashier', '{\"dashboard\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"products\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"sales\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"purchases\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"returns\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"credits\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"suppliers\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"cashbook\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"expenses\": {\"view\": 1, \"add\": 1, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"reports\": {\"view\": 1, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 1, \"export\": 0, \"import\": 0, \"void\": 0}, \"users\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"settings\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}, \"backup\": {\"view\": 0, \"add\": 0, \"edit\": 0, \"delete\": 0, \"print\": 0, \"export\": 0, \"import\": 0, \"void\": 0}}', '1', '2026-05-20 08:40:33');

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `generic_name` varchar(100) DEFAULT NULL,
  `brand_name` varchar(100) NOT NULL,
  `strength` varchar(100) DEFAULT NULL,
  `strength_unit` varchar(20) DEFAULT NULL,
  `dosage_form` varchar(100) DEFAULT NULL,
  `size_value` varchar(100) DEFAULT NULL,
  `unit_type` varchar(20) DEFAULT 'Pcs',
  `pack_type` varchar(50) DEFAULT NULL,
  `units_per_pack` int(11) NOT NULL DEFAULT 1,
  `quantity_of_packs` int(11) NOT NULL DEFAULT 1,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `sale_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pack_quantity` int(11) DEFAULT 1,
  `pieces_per_unit` int(11) DEFAULT 1,
  `is_variant` tinyint(1) DEFAULT 0,
  `variant_parent_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock_quantity` decimal(12,2) DEFAULT 0.00,
  `updated_at` timestamp NULL DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL COMMENT 'Primary barcode (quick access — full list in product_barcodes)',
  `image_path` varchar(255) DEFAULT NULL COMMENT 'Relative path to product image',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Soft-delete timestamp (NULL = active)',
  `deleted_by` int(11) DEFAULT NULL COMMENT 'User ID who soft-deleted this product',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `category_id` (`category_id`),
  KEY `idx_products_status_cat` (`status`,`category_id`),
  KEY `idx_products_name` (`product_name`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `product_barcodes`;
CREATE TABLE `product_barcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `barcode` varchar(50) NOT NULL,
  `barcode_type` enum('CODE128','EAN13','CODE39') DEFAULT 'CODE128',
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_barcode` (`barcode`),
  KEY `idx_pb_product` (`product_id`),
  KEY `idx_pb_variant` (`variant_id`),
  CONSTRAINT `fk_pb_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Product barcode registry — multiple barcodes per product/variant';

DROP TABLE IF EXISTS `product_batches`;
CREATE TABLE `product_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `units_per_pack` int(11) DEFAULT 1,
  `expiry_date` date DEFAULT NULL,
  `purchase_price` decimal(10,4) DEFAULT 0.0000,
  `selling_price` decimal(10,4) DEFAULT 0.0000,
  `quantity` decimal(10,2) DEFAULT 0.00,
  `initial_qty` decimal(10,2) DEFAULT 0.00,
  `is_expired` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_expiry` (`expiry_date`),
  KEY `idx_fifo` (`product_id`,`expiry_date`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `product_variants`;
CREATE TABLE `product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_name` varchar(50) NOT NULL,
  `variant_value` varchar(50) NOT NULL,
  `pack_quantity` int(11) DEFAULT 1,
  `pieces_per_pack` int(11) DEFAULT 1,
  `default_selling_price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `product_variants`
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('8', '4', 'Volume', '250ml', '1', '1', '150.00', '2026-05-06 15:57:42');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('9', '4', 'Volume', '500ml', '1', '1', '300.00', '2026-05-06 15:57:42');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('14', '2', 'Size', '250MG', '1', '1', '100.00', '2026-05-06 18:50:31');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('15', '2', 'Size', '625MG', '1', '1', '20.00', '2026-05-06 18:50:31');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('16', '2', 'Size', '100MG', '1', '1', '0.00', '2026-05-06 18:50:31');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('19', '3', 'Size', 'ONE', '1', '1', '0.00', '2026-05-06 18:53:55');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('20', '3', 'Size', 'ZERO', '1', '1', '0.00', '2026-05-06 18:53:55');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('21', '8', 'Size', '250mg', '10', '2', '5.00', '2026-05-06 19:02:35');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('22', '8', 'Size', '500mg', '10', '2', '10.00', '2026-05-06 19:02:35');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('23', '9', 'Size', 'Zero', '1', '48', '10.00', '2026-05-06 19:04:13');
INSERT INTO `product_variants` (`id`, `product_id`, `variant_name`, `variant_value`, `pack_quantity`, `pieces_per_pack`, `default_selling_price`, `created_at`) VALUES ('24', '9', 'Size', 'One', '1', '48', '14.99', '2026-05-06 19:04:13');

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_invoice_no` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) DEFAULT 0.00,
  `payment_status` enum('paid','partial','pending') DEFAULT 'pending',
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `due_amount` decimal(12,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `due_date` date DEFAULT NULL COMMENT 'Payment due date for this purchase',
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_invoice_no` (`purchase_invoice_no`),
  KEY `supplier_id` (`supplier_id`),
  KEY `idx_purchases_date` (`purchase_date`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `purchase_items`;
CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL COMMENT 'Number of packs',
  `pieces_per_pack` int(11) NOT NULL,
  `total_pieces` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL COMMENT 'Price per pack',
  `total` decimal(10,2) NOT NULL,
  `expiry_date` date NOT NULL,
  `selling_price` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `tax` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `batch_id` (`batch_id`),
  KEY `idx_purchase_items_purchase` (`purchase_id`),
  KEY `idx_purchase_id` (`purchase_id`),
  CONSTRAINT `purchase_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_items_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `purchase_returns`;
CREATE TABLE `purchase_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_no` varchar(50) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_item_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `return_date` datetime NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'approved',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `refund_method` varchar(20) DEFAULT 'cash',
  `credit_note_ref` varchar(100) DEFAULT NULL,
  `returned_by` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `return_mode` enum('pieces','packs') NOT NULL DEFAULT 'pieces',
  `packs_returned` int(11) DEFAULT NULL,
  `pieces_per_pack` int(11) NOT NULL DEFAULT 1,
  `original_unit_price` decimal(10,2) DEFAULT NULL,
  `return_unit_price` decimal(10,2) DEFAULT NULL,
  `price_adjustment` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_no` (`return_no`),
  KEY `purchase_id` (`purchase_id`),
  KEY `idx_purchase_returns_purchase_item` (`purchase_item_id`),
  KEY `idx_purchase_returns_batch` (`batch_id`),
  CONSTRAINT `purchase_returns_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(50) NOT NULL,
  `customer_name` varchar(100) DEFAULT 'Walk-in Customer',
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `sale_date` datetime NOT NULL,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `discount_percent` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `payment_method` enum('cash','card','online','credit') DEFAULT 'cash',
  `payment_status` enum('paid','partial','pending') DEFAULT 'paid',
  `is_credit` tinyint(1) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `voided_at` timestamp NULL DEFAULT NULL,
  `voided_by` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cashbook_entry_id` int(11) DEFAULT NULL COMMENT 'FK to cashbook.id — auto-set when sale is posted',
  `net_amount` decimal(10,2) DEFAULT 0.00,
  `grand_total` decimal(10,2) DEFAULT 0.00,
  `voided` tinyint(1) DEFAULT 0,
  `voided_reason` varchar(255) DEFAULT NULL,
  `tax_percent` decimal(5,2) DEFAULT 0.00,
  `due_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_no` (`invoice_no`),
  KEY `sale_date` (`sale_date`),
  KEY `idx_sales_date` (`sale_date`),
  KEY `idx_sales_date_payment` (`sale_date`,`payment_method`),
  KEY `idx_sales_customer_phone` (`customer_phone`),
  KEY `idx_sales_date_status` (`sale_date`,`status`),
  KEY `idx_sale_date` (`sale_date`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_is_credit` (`is_credit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) NOT NULL,
  `generic_name` varchar(100) DEFAULT NULL,
  `variant_info` varchar(100) DEFAULT NULL,
  `quantity` int(11) NOT NULL COMMENT 'Number of pieces sold',
  `unit_price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `item_discount_pct` decimal(5,2) DEFAULT 0.00 COMMENT 'Item-level discount percentage',
  `item_tax_pct` decimal(5,2) DEFAULT 0.00 COMMENT 'Item-level tax percentage',
  `item_discount_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'Calculated discount amount',
  `item_tax_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'Calculated tax amount',
  `purchase_price` decimal(10,4) DEFAULT 0.0000,
  `sell_mode` enum('piece','pack') NOT NULL DEFAULT 'piece',
  `units_per_pack` tinyint(3) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `batch_id` (`batch_id`),
  KEY `idx_sale_items_sale` (`sale_id`),
  KEY `idx_sale_items_product` (`product_id`),
  KEY `idx_sale_id` (`sale_id`),
  KEY `idx_batch_id` (`batch_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sale_returns`;
CREATE TABLE `sale_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_no` varchar(50) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `sale_item_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `return_date` datetime NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'approved',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `refund_method` varchar(30) NOT NULL DEFAULT 'cash',
  `returned_by` int(11) DEFAULT NULL,
  `voided` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_no` (`return_no`),
  KEY `sale_id` (`sale_id`),
  KEY `idx_sale_returns_sale_item` (`sale_item_id`),
  KEY `idx_sale_returns_batch` (`batch_id`),
  CONSTRAINT `sale_returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `movement_type` enum('purchase','sale','return_in','return_out','adjustment_in','adjustment_out') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'sale_id or purchase_id',
  `reference_type` varchar(20) DEFAULT NULL,
  `previous_quantity` int(11) DEFAULT NULL,
  `new_quantity` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `movement_type` (`movement_type`),
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `strengths`;
CREATE TABLE `strengths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `strength_value` varchar(50) NOT NULL,
  `strength_unit` varchar(20) DEFAULT NULL,
  `usage_count` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `strength_value_unit` (`strength_value`,`strength_unit`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `strengths`
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('1', '500', 'mg', '2', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('2', '250', 'mg', '1', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('3', '100', 'mg', '2', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('4', '625', 'mg', '4', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('5', '10', 'ml', '1', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('6', '5', 'ml', '1', '2026-05-05 18:40:31');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('7', '75', 'mg', '7', '2026-05-06 09:13:42');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('8', '100 mg', 'mg', '1', '2026-05-11 19:24:40');
INSERT INTO `strengths` (`id`, `strength_value`, `strength_unit`, `usage_count`, `created_at`) VALUES ('9', '150mg', 'mg', '1', '2026-05-13 12:28:20');

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(50) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `alternative_phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gst_no` varchar(50) DEFAULT NULL,
  `opening_balance` decimal(10,2) DEFAULT 0.00,
  `current_balance` decimal(10,2) DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `balance` decimal(12,2) DEFAULT 0.00,
  `due_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `supplier_payments`;
CREATE TABLE `supplier_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL COMMENT 'FK to users.id — who recorded this payment',
  `reference_no` varchar(100) DEFAULT NULL COMMENT 'Invoice or cheque reference number',
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `supplier_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `supplier_payments_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `system_preferences`;
CREATE TABLE `system_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `low_stock_threshold` int(11) DEFAULT 10,
  `near_expiry_days` int(11) DEFAULT 30,
  `invoice_footer` varchar(255) DEFAULT 'Thank you! Visit Again',
  `enable_gst` tinyint(1) DEFAULT 0,
  `tax_percentage` decimal(5,2) DEFAULT 0.00,
  `default_discount` decimal(5,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `system_preferences`
INSERT INTO `system_preferences` (`id`, `low_stock_threshold`, `near_expiry_days`, `invoice_footer`, `enable_gst`, `tax_percentage`, `default_discount`, `created_at`) VALUES ('1', '10', '30', 'Thank you! Visit Again', '0', '0.00', '0.00', '2026-05-05 19:32:27');

DROP TABLE IF EXISTS `system_resets`;
CREATE TABLE `system_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_type` enum('full','financial','transaction') NOT NULL,
  `reset_by` int(11) NOT NULL,
  `reset_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `backup_filename_before` varchar(255) DEFAULT NULL,
  `rows_deleted_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Counts of rows deleted per table' CHECK (json_valid(`rows_deleted_json`)),
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reset_at` (`reset_at`),
  KEY `idx_reset_by` (`reset_by`),
  KEY `idx_reset_type` (`reset_type`),
  KEY `idx_system_resets_at` (`reset_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','pharmacist','cashier') DEFAULT 'pharmacist',
  `profile_image` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `permissions_set` tinyint(1) DEFAULT 0 COMMENT '1 = admin has customised permissions for this user',
  `remember_expires` datetime DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `default_page` varchar(50) DEFAULT 'dashboard',
  `session_timeout_override` int(11) DEFAULT NULL COMMENT 'Overrides global session_timeout for this user (minutes)',
  `remember_token_expires` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `login_count` int(11) DEFAULT 0,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `force_password_change` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `security_question` varchar(100) DEFAULT NULL,
  `security_answer` varchar(255) DEFAULT NULL,
  `is_first_login` tinyint(1) NOT NULL DEFAULT 1,
  `session_token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_remember_token` (`remember_token`(32)),
  KEY `idx_username` (`username`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module` varchar(50) NOT NULL,
  `can_view` tinyint(1) DEFAULT 0,
  `can_add` tinyint(1) DEFAULT 0,
  `can_edit` tinyint(1) DEFAULT 0,
  `can_delete` tinyint(1) DEFAULT 0,
  `can_print` tinyint(1) DEFAULT 0,
  `can_export` tinyint(1) DEFAULT 0,
  `can_import` tinyint(1) DEFAULT 0,
  `can_void` tinyint(1) DEFAULT 0,
  `can_reset` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_module` (`user_id`,`module`),
  KEY `idx_user_perm_user` (`user_id`),
  KEY `idx_user_perm_module` (`module`),
  CONSTRAINT `fk_up_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Per-user module-level access control';

-- Data for `user_permissions`
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('42', '1', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('43', '1', 'products', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('44', '1', 'sales', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('45', '1', 'purchases', '1', '1', '1', '1', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('46', '1', 'returns', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('47', '1', 'credits', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('48', '1', 'suppliers', '1', '1', '1', '1', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('49', '1', 'cashbook', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('50', '1', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('51', '1', 'reports', '1', '0', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('52', '1', 'users', '1', '1', '1', '1', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('53', '1', 'settings', '1', '0', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('54', '1', 'backup', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('107', '7', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('108', '7', 'products', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('109', '7', 'sales', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('110', '7', 'purchases', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('111', '7', 'returns', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('112', '7', 'credits', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('113', '7', 'suppliers', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('114', '7', 'cashbook', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('115', '7', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('116', '7', 'reports', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('117', '7', 'users', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('118', '7', 'settings', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('119', '7', 'backup', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('120', '8', 'dashboard', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('121', '8', 'products', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('122', '8', 'sales', '1', '1', '0', '0', '1', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('123', '8', 'purchases', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('124', '8', 'returns', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('125', '8', 'credits', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('126', '8', 'suppliers', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('127', '8', 'cashbook', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('128', '8', 'expenses', '1', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('129', '8', 'reports', '1', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('130', '8', 'users', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('131', '8', 'settings', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `user_permissions` (`id`, `user_id`, `module`, `can_view`, `can_add`, `can_edit`, `can_delete`, `can_print`, `can_export`, `can_import`, `can_void`, `can_reset`) VALUES ('132', '8', 'backup', '0', '0', '0', '0', '0', '0', '0', '0', '0');


-- ════ VIEWS ════
DROP VIEW IF EXISTS `expiry_alerts_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `expiry_alerts_view` AS select `b`.`id` AS `batch_id`,`b`.`batch_number` AS `batch_number`,`p`.`product_name` AS `product_name`,`p`.`generic_name` AS `generic_name`,`b`.`expiry_date` AS `expiry_date`,`b`.`remaining_quantity` AS `remaining_quantity`,to_days(`b`.`expiry_date`) - to_days(curdate()) AS `days_to_expire`,case when to_days(`b`.`expiry_date`) - to_days(curdate()) <= 0 then 'Expired' when to_days(`b`.`expiry_date`) - to_days(curdate()) <= 30 then 'Critical' when to_days(`b`.`expiry_date`) - to_days(curdate()) <= 90 then 'Warning' else 'Normal' end AS `expiry_status` from (`batches` `b` join `products` `p` on(`b`.`product_id` = `p`.`id`)) where `b`.`remaining_quantity` > 0 order by `b`.`expiry_date`;

DROP VIEW IF EXISTS `stock_summary_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stock_summary_view` AS select `p`.`id` AS `product_id`,`p`.`product_name` AS `product_name`,`p`.`generic_name` AS `generic_name`,`p`.`brand_name` AS `brand_name`,`p`.`strength` AS `strength`,`p`.`strength_unit` AS `strength_unit`,`p`.`dosage_form` AS `dosage_form`,`p`.`unit_type` AS `unit_type`,`p`.`pack_quantity` AS `pack_quantity`,coalesce(sum(`b`.`remaining_quantity`),0) AS `stock_in_pieces`,count(distinct `b`.`id`) AS `batch_count`,min(`b`.`expiry_date`) AS `nearest_expiry`,case when coalesce(sum(`b`.`remaining_quantity`),0) = 0 then 'Out of Stock' when coalesce(sum(`b`.`remaining_quantity`),0) <= `p`.`reorder_level` then 'Low Stock' else 'In Stock' end AS `stock_status` from (`products` `p` left join `batches` `b` on(`p`.`id` = `b`.`product_id` and `b`.`is_expired` = 0 and `b`.`is_blocked` = 0)) where `p`.`status` = 1 group by `p`.`id`;

DROP VIEW IF EXISTS `v_active_credits`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_active_credits` AS select `cc`.`id` AS `id`,`cc`.`sale_id` AS `sale_id`,`cc`.`customer_name` AS `customer_name`,`cc`.`customer_phone` AS `customer_phone`,`cc`.`total_amount` AS `total_amount`,`cc`.`due_date` AS `due_date`,`cc`.`description` AS `description`,`cc`.`status` AS `status`,`cc`.`created_at` AS `created_at`,coalesce(sum(`cp`.`amount`),0) AS `total_paid`,`cc`.`total_amount` - coalesce(sum(`cp`.`amount`),0) AS `remaining`,`s`.`invoice_no` AS `invoice_no`,`s`.`sale_date` AS `sale_date` from ((`customer_credits` `cc` left join `credit_payments` `cp` on(`cp`.`credit_id` = `cc`.`id`)) left join `sales` `s` on(`s`.`id` = `cc`.`sale_id`)) where `cc`.`status` = 'active' group by `cc`.`id`;

DROP VIEW IF EXISTS `v_product_stock`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_product_stock` AS select `batches`.`product_id` AS `product_id`,sum(`batches`.`remaining_quantity`) AS `total_stock`,count(0) AS `batch_count`,min(`batches`.`expiry_date`) AS `nearest_expiry`,min(`batches`.`purchase_price`) AS `min_purchase_price`,max(`batches`.`purchase_price`) AS `max_purchase_price` from `batches` where `batches`.`is_expired` = 0 and `batches`.`is_blocked` = 0 and `batches`.`expiry_date` > current_timestamp() group by `batches`.`product_id`;

DROP VIEW IF EXISTS `v_sales_with_returns`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sales_with_returns` AS select `s`.`id` AS `id`,`s`.`invoice_no` AS `invoice_no`,`s`.`customer_name` AS `customer_name`,`s`.`customer_phone` AS `customer_phone`,`s`.`sale_date` AS `sale_date`,`s`.`total` AS `total_amount`,`s`.`paid_amount` AS `paid_amount`,`s`.`payment_method` AS `payment_method`,`s`.`payment_status` AS `payment_status`,`s`.`is_credit` AS `is_credit`,coalesce(sum(`sr`.`total_amount`),0) AS `total_returned`,coalesce(`s`.`total`,0) - coalesce(sum(`sr`.`total_amount`),0) AS `net_amount` from (`sales` `s` left join `sale_returns` `sr` on(`sr`.`sale_id` = `s`.`id`)) where `s`.`status` <> 'voided' group by `s`.`id`;

SET FOREIGN_KEY_CHECKS = 1;
